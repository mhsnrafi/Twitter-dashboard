configure({
  configs: [
    './prod.js'
  ]
});
